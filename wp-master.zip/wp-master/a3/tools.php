<?php
  session_start();

// Put your PHP functions and modules here

?>